#pragma once

namespace kcov
{
	enum match_type
	{
		match_none = 0,
		match_perfect = 0xffffffff,
	};
}
