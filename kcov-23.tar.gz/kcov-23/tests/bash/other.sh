#!/bin/sh

echo "This is another shell script"

if [ $1 -eq 5 ] ; then
	echo "Kalle anka"
fi

