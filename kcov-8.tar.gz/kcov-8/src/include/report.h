/*
 * Copyright (C) 2010 Thomas Neumann, Simon Kagstrom
 *
 * See COPYING for license details
 */
struct kc;

void write_report(const char *dir, struct kc *kc);
