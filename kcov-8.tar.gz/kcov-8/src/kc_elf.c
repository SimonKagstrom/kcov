/*
 * Copyright (C) 2010 Simon Kagstrom, Thomas Neumann
 *
 * See COPYING for license details
 */
#include <kc.h>
#include <utils.h>

struct kc_elf *kc_elf_new(const char *filename)
{
	return NULL;
}
