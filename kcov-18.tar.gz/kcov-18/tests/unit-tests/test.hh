#pragma once

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <crpcut.hpp>

using namespace testing;
