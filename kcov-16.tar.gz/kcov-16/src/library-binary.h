#pragma once

#include <stdlib.h>
#include <stdint.h>

extern size_t __library_data_size;
extern uint8_t __library_data[];
