#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xd4733cff, "module_layout" },
	{ 0x7c904ded, "unregister_module_notifier" },
	{ 0x14aad2df, "debugfs_remove_recursive" },
	{ 0xce65a0a8, "__mutex_init" },
	{ 0x48eb0c0d, "__init_waitqueue_head" },
	{ 0x59d696b6, "register_module_notifier" },
	{ 0x6147ebb2, "debugfs_create_file" },
	{ 0x50eedeb8, "printk" },
	{ 0x108cf176, "debugfs_create_dir" },
	{ 0x85df9b6c, "strsep" },
	{ 0xc499ae1e, "kstrdup" },
	{ 0x97e794ea, "find_module" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x1e6d26a8, "strstr" },
	{ 0x33d169c9, "_copy_from_user" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0x8949858b, "schedule_work" },
	{ 0xe45f60d8, "__wake_up" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x2da418b5, "copy_to_user" },
	{ 0x37a0cba, "kfree" },
	{ 0xb81960ca, "snprintf" },
	{ 0xcc99e735, "mutex_unlock" },
	{ 0xa5dd69ea, "mutex_lock" },
	{ 0x75bb675a, "finish_wait" },
	{ 0x4292364c, "schedule" },
	{ 0x622fa02a, "prepare_to_wait" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0x95435001, "current_task" },
	{ 0x3841ab01, "unregister_kprobe" },
	{ 0x6b94c408, "enable_kprobe" },
	{ 0xdc714560, "register_kprobe" },
	{ 0xe2d5255a, "strcmp" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

