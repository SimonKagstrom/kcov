#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xd4733cff, "module_layout" },
	{ 0x5e7b2cb4, "single_release" },
	{ 0x121e27eb, "seq_read" },
	{ 0x9cbf34ac, "seq_lseek" },
	{ 0x4f4dcfda, "remove_proc_entry" },
	{ 0x22088018, "create_proc_entry" },
	{ 0x50eedeb8, "printk" },
	{ 0x96c7e43b, "seq_printf" },
	{ 0x5b5f9d7a, "single_open" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

