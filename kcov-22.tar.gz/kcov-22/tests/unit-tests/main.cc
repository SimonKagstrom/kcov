#include "test.hh"
#include "mocks/mock-engine.hh"

using namespace kcov;

int main(int argc, const char *argv[])
{
	return crpcut::run(argc, argv);
}
