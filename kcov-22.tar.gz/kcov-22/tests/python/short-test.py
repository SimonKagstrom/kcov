#!/usr/bin/python

import sys

def doSomething():
    print 'Hello world'


if __name__ == '__main__':
    doSomething()
